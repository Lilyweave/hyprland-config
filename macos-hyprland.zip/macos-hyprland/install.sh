#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
mkdir -p ~/.config/hypr ~/.config/waybar ~/.config/rofi ~/.config/nwg-dock-hyprland

# back up existing hyprland config
[ -f ~/.config/hypr/hyprland.conf ] && cp ~/.config/hypr/hyprland.conf ~/.config/hypr/hyprland.conf.bak

cp hypr/hyprland.conf               ~/.config/hypr/hyprland.conf
cp waybar/config.jsonc waybar/style.css ~/.config/waybar/
cp rofi/spotlight.rasi              ~/.config/rofi/
cp nwg-dock-hyprland/style.css      ~/.config/nwg-dock-hyprland/style.css

echo "Done. Log out and back in (or run: hyprctl reload)."
